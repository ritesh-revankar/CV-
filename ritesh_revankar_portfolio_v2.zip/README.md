# Ritesh Rajesh Revankar — Portfolio

A simple, human-looking portfolio for a CMR University B.Tech CSE student.

Design goal:
- Minimal
- Light
- Clean
- Student portfolio feel
- No AI-looking gradients, dashboards, terminal windows, excessive cards, or decorative graphics

Facts included:
- CMR University
- B.Tech CSE, 3rd Year / 5th Semester
- Bengaluru
- Python, HTML, CSS, Docker, ESP32, Raspberry Pi
- Interests: Full Stack Development, Cybersecurity, App Development, Web Development
- Bladerunner: retro multiplayer
- Campus Hub: campus events management
- GitHub and LinkedIn
- No internship or certifications
